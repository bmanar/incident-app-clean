package com.example.backend.repository;

import com.example.backend.model.EquipeEnCharge;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EquipeEnChargeRepository extends JpaRepository<EquipeEnCharge, Long> {}
