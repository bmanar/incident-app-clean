package com.example.backend.controller;

import com.example.backend.model.Incident;
import com.example.backend.model.SourceIncident;
import com.example.backend.repository.IncidentRepository;
import com.example.backend.repository.SourceIncidentRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.http.ResponseEntity;
import org.springframework.core.io.UrlResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/api/incidents")
public class IncidentController {

    @Autowired
    private IncidentRepository incidentRepository;

    @Autowired
    private SourceIncidentRepository sourceRepo;

    @PostMapping(consumes = {"multipart/form-data"})
    public Incident createIncident(
        @RequestParam("description") String description,
        @RequestParam("prioriteMetier") String prioriteMetier,
        @RequestParam("sourceIncidentId") Long sourceIncidentId,
        @RequestParam("dateRemontee") String dateRemontee,
        @RequestParam("montantPertes") Double montantPertes,
        @RequestParam("nombre") Integer nombre,
        @RequestParam("periode") String periode,
        @RequestPart(value = "pieceJointe", required = false) MultipartFile pieceJointe
    ) throws Exception {
        Incident incident = new Incident();
        incident.setDescription(description);
        incident.setPrioriteMetier(prioriteMetier);
        incident.setDateRemontee(LocalDate.parse(dateRemontee));
        incident.setMontantPertes(montantPertes);
        incident.setNombre(nombre);
        incident.setPeriode(periode);

        // 🔁 **Ici on récupère la SourceIncident correspondante**
        SourceIncident src = sourceRepo.findById(sourceIncidentId)
            .orElseThrow(() -> new IllegalArgumentException("Source non trouvée id=" + sourceIncidentId));
        incident.setSourceIncident(src);

        // ⚙️ Gestion du fichier
        if (pieceJointe != null && !pieceJointe.isEmpty()) {
            String fileName = System.currentTimeMillis() + "_" + pieceJointe.getOriginalFilename();
            Path target = Paths.get("uploads").resolve(fileName);
            Files.createDirectories(target.getParent());
            pieceJointe.transferTo(target.toFile());
            incident.setPieceJointe(fileName);
        }

        return incidentRepository.save(incident);
    }

    @GetMapping
    public List<Incident> getAll() {
        return incidentRepository.findAll();
    }

    @GetMapping("/piece-jointe/{filename:.+}")
    public ResponseEntity<Resource> download(@PathVariable String filename) throws Exception {
        Path file = Paths.get("uploads").resolve(filename);
        Resource res = new UrlResource(file.toUri());
        if (!res.exists()) return ResponseEntity.notFound().build();

        return ResponseEntity.ok()
            .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + res.getFilename() + "\"")
            .body(res);
    }

}  