package com.example.backend.controller;

import com.example.backend.repository.IncidentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.time.format.DateTimeFormatter;
import java.util.*;

@RestController
@RequestMapping("/api/stats")
public class StatsController {

    @Autowired
    private IncidentRepository incidentRepository;

    @GetMapping("/dashboard")
    public Map<String, Object> getDashboardStats() {
        Map<String, Object> res = new LinkedHashMap<>();

        // Nombre d'incidents par statut
        List<Object[]> statuts = incidentRepository.countByStatutIncident();
        Map<String, Long> incidentsParStatut = new LinkedHashMap<>();
        for (Object[] row : statuts) {
            incidentsParStatut.put((String) row[0], (Long) row[1]);
        }
        res.put("incidentsParStatut", incidentsParStatut);

        // Nombre d'incidents par mois (sur 12 mois glissants)
        List<Object[]> parMois = incidentRepository.countByMois();
        List<Map<String, Object>> incidentsParMois = new ArrayList<>();
        for (Object[] row : parMois) {
            Map<String, Object> item = new LinkedHashMap<>();
            item.put("mois", (String) row[0]);
            item.put("count", ((Long) row[1]));
            incidentsParMois.add(item);
        }
        res.put("incidentsParMois", incidentsParMois);

        // Montant total des pertes
        Long total = incidentRepository.montantTotalPertes();
        res.put("montantTotalPertes", total == null ? 0 : total);

        // Nombre d'incidents par source
        List<Object[]> parSource = incidentRepository.countBySource();
        Map<String, Long> incidentsParSource = new LinkedHashMap<>();
        for (Object[] row : parSource) {
            incidentsParSource.put((String) row[0], (Long) row[1]);
        }
        res.put("incidentsParSource", incidentsParSource);

        // Nombre d'incidents par priorité
        List<Object[]> parPriorite = incidentRepository.countByPriorite();
        Map<String, Long> incidentsParPriorite = new LinkedHashMap<>();
        for (Object[] row : parPriorite) {
            incidentsParPriorite.put((String) row[0], (Long) row[1]);
        }
        res.put("incidentsParPriorite", incidentsParPriorite);

        return res;
    }
}