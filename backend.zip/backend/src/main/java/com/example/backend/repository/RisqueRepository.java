package com.example.backend.repository;

import com.example.backend.model.Risque;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RisqueRepository extends JpaRepository<Risque, Long> {}
