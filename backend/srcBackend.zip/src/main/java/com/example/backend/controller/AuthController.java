package com.example.backend.controller;

import com.example.backend.model.Utilisateur;
import com.example.backend.repository.UtilisateurRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

/**
 * Contrôleur pour gérer l'authentification.
 */
@RestController
@RequestMapping("/api/utilisateurs")
// @CrossOrigin(origins = "http://localhost:3000") // autorise seulement le front local
public class AuthController {

    @Autowired
    private UtilisateurRepository utilisateurRepository;

    /**
     * Point de connexion simple : renvoie l'utilisateur si mail + password sont bons.
     */
    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody LoginRequest request) {
        try {
            System.out.println("Requête de login reçue : " + request.getMail());

            Optional<Utilisateur> userOpt = utilisateurRepository.findByMail(request.getMail());

            if (userOpt.isPresent()) {
                Utilisateur utilisateur = userOpt.get();

                if (utilisateur.getPassword().equals(request.getPassword())) {
                    utilisateur.setPassword(null); // Sécurité
                    return ResponseEntity.ok(utilisateur);
                } else {
                    System.out.println("Mot de passe incorrect");
                }
            } else {
                System.out.println("Utilisateur non trouvé");
            }

            return ResponseEntity.status(401).body("Email ou mot de passe incorrect");

        } catch (Exception e) {
            System.out.println("Erreur serveur : " + e.getMessage());
            return ResponseEntity.status(500).body("Erreur interne du serveur");
        }
    }

    /**
     * Classe pour mapper les données du formulaire de connexion.
     */
    public static class LoginRequest {
        private String mail;
        private String password;

        public String getMail() {
            return mail;
        }

        public void setMail(String mail) {
            this.mail = mail;
        }

        public String getPassword() {
            return password;
        }

        public void setPassword(String password) {
            this.password = password;
        }
    }
}