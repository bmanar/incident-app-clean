package com.example.backend.controller;

import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/utilisateurs")
public class AuthController {
    // Désormais géré automatiquement par Spring Security
}