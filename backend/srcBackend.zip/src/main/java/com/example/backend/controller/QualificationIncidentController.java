package com.example.backend.controller;

import com.example.backend.model.Incident;
import com.example.backend.model.QualificationIncident;
import com.example.backend.repository.IncidentRepository;
import com.example.backend.repository.QualificationIncidentRepository;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/qualification-incidents")
@CrossOrigin(origins = "http://localhost:3000", allowCredentials = "true")
public class QualificationIncidentController {

    @Autowired
    private QualificationIncidentRepository qualificationIncidentRepository;

    @Autowired
    private IncidentRepository incidentRepository;

    @PostMapping("/{incidentId}")
    public QualificationIncident qualifyIncident(
            @PathVariable Long incidentId,
            @Valid @RequestBody QualificationIncident qualificationIncident) {

        Incident incident = incidentRepository.findById(incidentId)
                .orElseThrow(() -> new RuntimeException("Incident non trouvé avec l'ID : " + incidentId));

        // Association bidirectionnelle
        qualificationIncident.setIncident(incident);
        incident.setQualification(qualificationIncident);

        // Mise à jour du statut
        incident.setStatutIncident("Qualifié");

        incidentRepository.save(incident);
        return qualificationIncidentRepository.save(qualificationIncident);
    }

    @GetMapping
    public List<QualificationIncident> getAllQualifications() {
        return qualificationIncidentRepository.findAll();
    }

    @GetMapping("/{id}")
    public QualificationIncident getQualificationById(@PathVariable Long id) {
        return qualificationIncidentRepository.findById(id).orElse(null);
    }
}