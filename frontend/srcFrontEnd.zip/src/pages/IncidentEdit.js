import React, { useEffect, useState } from "react";
import {
  Box,
  Typography,
  TextField,
  MenuItem,
  Button,
  Paper,
  Select,
  FormControl,
  InputLabel,
  CircularProgress,
  Alert,
  RadioGroup,
  Radio,
  FormLabel,
  FormControlLabel,
} from "@mui/material";
import { useParams, useNavigate } from "react-router-dom";

const STATUS = ["Nouveau", "En cours", "Traité", "Abandonné"];
const PRIORITIES = ["P0", "P1", "P2", "P3"];

export default function IncidentEdit() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [incident, setIncident] = useState(null);
  const [form, setForm] = useState({
    description: "",
    prioriteMetier: "",
    montantPertes: "",
    nombre: "",
    periode: "",
    statutIncident: "",
  });
  const [loading, setLoading] = useState(true);
  const [alert, setAlert] = useState("");

  useEffect(() => {
    fetch(`http://localhost:8080/api/incidents/${id}`)
      .then((res) => res.json())
      .then((data) => {
        setIncident(data);
        setForm({
          description: data.description || "",
          prioriteMetier: data.prioriteMetier || "",
          montantPertes: data.montantPertes || "",
          nombre: data.nombre || "",
          periode: data.periode || "",
          statutIncident: data.statutIncident || "Nouveau",
        });
        setLoading(false);
      });
  }, [id]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm((f) => ({ ...f, [name]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    fetch(`http://localhost:8080/api/incidents/${id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ...incident, ...form }),
    })
      .then((res) => res.json())
      .then(() => {
        setAlert("Incident modifié !");
        setTimeout(() => {
          setAlert("");
          navigate("/liste");
        }, 1200);
      });
  };

  if (loading)
    return (
      <Box p={6} textAlign="center">
        <CircularProgress />
      </Box>
    );

  return (
    <Box maxWidth={600} mx="auto" mt={6}>
      <Paper sx={{ p: 4, borderRadius: 4, boxShadow: 2 }}>
        <Typography variant="h5" fontWeight={700} mb={3}>
          Éditer l’incident #{incident.id}
        </Typography>

        {alert && (
          <Alert severity="success" sx={{ mb: 2 }}>
            {alert}
          </Alert>
        )}

        <form onSubmit={handleSubmit}>
          <TextField
            label="Description"
            name="description"
            fullWidth
            margin="normal"
            value={form.description}
            onChange={handleChange}
            required
          />
          {/* Priorité radio */}
          <FormControl fullWidth margin="normal">
            <FormLabel id="priorite-radio-group-label">Priorité</FormLabel>
            <RadioGroup
              row
              aria-labelledby="priorite-radio-group-label"
              name="prioriteMetier"
              value={form.prioriteMetier}
              onChange={handleChange}
            >
              {PRIORITIES.map((p) => (
                <FormControlLabel
                  key={p}
                  value={p}
                  control={<Radio color="primary" />}
                  label={p}
                />
              ))}
            </RadioGroup>
          </FormControl>
          <TextField
            label="Montant des pertes"
            name="montantPertes"
            type="number"
            fullWidth
            margin="normal"
            value={form.montantPertes}
            onChange={handleChange}
            required
          />
          <TextField
            label="Nombre"
            name="nombre"
            type="number"
            fullWidth
            margin="normal"
            value={form.nombre}
            onChange={handleChange}
            required
          />
          <TextField
            label="Période"
            name="periode"
            fullWidth
            margin="normal"
            value={form.periode}
            onChange={handleChange}
            required
          />
          {/* Statut menu déroulant */}
          <FormControl fullWidth margin="normal">
            <InputLabel id="statut-label">Statut</InputLabel>
            <Select
              labelId="statut-label"
              name="statutIncident"
              value={form.statutIncident}
              label="Statut"
              onChange={handleChange}
              required
            >
              {STATUS.map((st) => (
                <MenuItem key={st} value={st}>
                  {st}
                </MenuItem>
              ))}
            </Select>
          </FormControl>
          <Box mt={3} display="flex" gap={2}>
            <Button type="submit" variant="contained" color="primary">
              Enregistrer
            </Button>
            <Button
              variant="outlined"
              color="secondary"
              onClick={() => navigate("/liste")}
            >
              Annuler
            </Button>
          </Box>
        </form>
      </Paper>
    </Box>
  );
}
