import React, { useEffect, useState } from "react";
import {
  Card,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Avatar,
  Box,
  Chip,
  Typography,
  TextField,
  InputAdornment,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  TableSortLabel,
  IconButton,
  Alert,
} from "@mui/material";
import EuroIcon from "@mui/icons-material/Euro";
import BugReportIcon from "@mui/icons-material/BugReport";
import EditIcon from "@mui/icons-material/Edit";
import DeleteIcon from "@mui/icons-material/Delete";
import SearchIcon from "@mui/icons-material/Search";
import AttachFileIcon from "@mui/icons-material/AttachFile";
import { useNavigate } from "react-router-dom";

function descendingComparator(a, b, orderBy) {
  if (b[orderBy] < a[orderBy]) return -1;
  if (b[orderBy] > a[orderBy]) return 1;
  return 0;
}

function getComparator(order, orderBy) {
  return order === "desc"
    ? (a, b) => descendingComparator(a, b, orderBy)
    : (a, b) => -descendingComparator(a, b, orderBy);
}

function stableSort(array, comparator) {
  const stabilized = array.map((el, idx) => [el, idx]);
  stabilized.sort((a, b) => {
    const order = comparator(a[0], b[0]);
    if (order !== 0) return order;
    return a[1] - b[1];
  });
  return stabilized.map((el) => el[0]);
}

export default function IncidentsList() {
  const [incidents, setIncidents] = useState([]);
  const [filtered, setFiltered] = useState([]);
  const [sources, setSources] = useState([]);
  const [search, setSearch] = useState("");
  const [filterSource, setFilterSource] = useState("");
  const [filterPriorite, setFilterPriorite] = useState("");
  const [order, setOrder] = useState("desc");
  const [orderBy, setOrderBy] = useState("id");
  const [alert, setAlert] = useState("");
  const navigate = useNavigate();

  useEffect(() => {
    fetch("http://localhost:8080/api/incidents")
      .then((res) => res.json())
      .then((data) => {
        setIncidents(data);
        setFiltered(data);
      });
    fetch("http://localhost:8080/api/sources-incidents")
      .then((res) => res.json())
      .then((data) => setSources(data));
  }, []);

  useEffect(() => {
    let data = incidents;
    if (search.trim() !== "") {
      data = data.filter((i) =>
        (i.description ?? "").toLowerCase().includes(search.toLowerCase())
      );
    }
    if (filterSource !== "") {
      data = data.filter(
        (i) =>
          i.sourceIncident &&
          String(i.sourceIncident.id) === String(filterSource)
      );
    }
    if (filterPriorite !== "") {
      data = data.filter((i) => i.prioriteMetier === filterPriorite);
    }
    setFiltered(data);
  }, [search, filterSource, filterPriorite, incidents]);

  const handleRequestSort = (property) => {
    const isAsc = orderBy === property && order === "asc";
    setOrder(isAsc ? "desc" : "asc");
    setOrderBy(property);
  };

  const handleDelete = (id) => {
    if (window.confirm("Supprimer cet incident ?")) {
      fetch(`http://localhost:8080/api/incidents/${id}`, {
        method: "DELETE",
      }).then(() => {
        setIncidents(incidents.filter((i) => i.id !== id));
        setFiltered(filtered.filter((i) => i.id !== id));
        setAlert("Incident supprimé !");
        setTimeout(() => setAlert(""), 2000);
      });
    }
  };

  return (
    <>
      <Box
        sx={{
          maxWidth: 1200,
          mx: "auto",
          mt: 5,
          p: 3,
          background: "linear-gradient(120deg,#f6f7fb 60%,#e8edfa 100%)",
          borderRadius: 4,
          boxShadow: 3,
        }}
      >
        <Box display="flex" alignItems="center" mb={2}>
          <Avatar sx={{ bgcolor: "#1976d2", mr: 2 }}>
            <BugReportIcon />
          </Avatar>
          <Typography variant="h4" fontWeight={700}>
            Liste des incidents
          </Typography>
        </Box>

        {alert && (
          <Alert severity="success" sx={{ mb: 2 }}>
            {alert}
          </Alert>
        )}

        {/* Filtres */}
        <Box display="flex" gap={2} mb={2} flexWrap="wrap">
          <TextField
            label="Recherche (description)"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <SearchIcon />
                </InputAdornment>
              ),
            }}
            sx={{ width: 220, minWidth: 180 }}
          />

          <FormControl sx={{ width: 180, minWidth: 150 }}>
            <InputLabel id="source-filter-label">Source</InputLabel>
            <Select
              labelId="source-filter-label"
              value={filterSource}
              label="Source"
              onChange={(e) => setFilterSource(e.target.value)}
            >
              <MenuItem value="">Toutes</MenuItem>
              {sources.map((src) => (
                <MenuItem key={src.id} value={src.id}>
                  {src.nom}
                </MenuItem>
              ))}
            </Select>
          </FormControl>

          <FormControl sx={{ width: 150, minWidth: 120 }}>
            <InputLabel id="priorite-filter-label">Priorité</InputLabel>
            <Select
              labelId="priorite-filter-label"
              value={filterPriorite}
              label="Priorité"
              onChange={(e) => setFilterPriorite(e.target.value)}
            >
              <MenuItem value="">Toutes</MenuItem>
              {["P0", "P1", "P2", "P3"].map((p) => (
                <MenuItem key={p} value={p}>
                  {p}
                </MenuItem>
              ))}
            </Select>
          </FormControl>
        </Box>

        <TableContainer component={Card} sx={{ borderRadius: 3 }}>
          <Table>
            <TableHead>
              <TableRow sx={{ background: "#e8edfa" }}>
                <TableCell>
                  <TableSortLabel
                    active={orderBy === "id"}
                    direction={orderBy === "id" ? order : "asc"}
                    onClick={() => handleRequestSort("id")}
                  >
                    <b>ID</b>
                  </TableSortLabel>
                </TableCell>
                <TableCell>
                  <TableSortLabel
                    active={orderBy === "dateRemontee"}
                    direction={orderBy === "dateRemontee" ? order : "asc"}
                    onClick={() => handleRequestSort("dateRemontee")}
                  >
                    <b>Date</b>
                  </TableSortLabel>
                </TableCell>
                <TableCell>
                  <b>Description</b>
                </TableCell>
                <TableCell>
                  <TableSortLabel
                    active={orderBy === "prioriteMetier"}
                    direction={orderBy === "prioriteMetier" ? order : "asc"}
                    onClick={() => handleRequestSort("prioriteMetier")}
                  >
                    <b>Priorité</b>
                  </TableSortLabel>
                </TableCell>
                <TableCell>
                  <TableSortLabel
                    active={orderBy === "sourceIncident"}
                    direction={orderBy === "sourceIncident" ? order : "asc"}
                    onClick={() => handleRequestSort("sourceIncident")}
                  >
                    <b>Source</b>
                  </TableSortLabel>
                </TableCell>
                <TableCell align="right">
                  <TableSortLabel
                    active={orderBy === "montantPertes"}
                    direction={orderBy === "montantPertes" ? order : "asc"}
                    onClick={() => handleRequestSort("montantPertes")}
                  >
                    <b>Montant des pertes</b>
                  </TableSortLabel>
                </TableCell>
                <TableCell align="center">
                  <b>PJ</b>
                </TableCell>
                <TableCell align="center">
                  <b>Statut</b>
                </TableCell>
                <TableCell align="center">
                  <b>Actions</b>
                </TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {stableSort(filtered, getComparator(order, orderBy)).map(
                (incident) => (
                  <TableRow key={incident.id}>
                    <TableCell>{incident.id}</TableCell>
                    <TableCell>{incident.dateRemontee}</TableCell>
                    <TableCell>{incident.description}</TableCell>
                    <TableCell>
                      <Chip
                        label={incident.prioriteMetier}
                        color={
                          incident.prioriteMetier === "P0"
                            ? "error"
                            : incident.prioriteMetier === "P1"
                            ? "warning"
                            : incident.prioriteMetier === "P2"
                            ? "info"
                            : "default"
                        }
                      />
                    </TableCell>
                    <TableCell>
                      {incident.sourceIncident && incident.sourceIncident.nom
                        ? incident.sourceIncident.nom
                        : "-"}
                    </TableCell>
                    <TableCell align="right">
                      {incident.montantPertes != null
                        ? `${incident.montantPertes} €`
                        : "-"}
                    </TableCell>
                    <TableCell align="center">
                      {incident.pieceJointe ? (
                        <a
                          href={`http://localhost:8080/api/incidents/piece-jointe/${incident.pieceJointe}`}
                          target="_blank"
                          rel="noopener noreferrer"
                          style={{ color: "inherit" }}
                          title="Télécharger la pièce jointe"
                        >
                          <AttachFileIcon color="success" />
                        </a>
                      ) : (
                        <AttachFileIcon
                          color="disabled"
                          titleAccess="Aucune pièce jointe"
                        />
                      )}
                    </TableCell>
                    <TableCell align="center">
                      {incident.statutIncident ? incident.statutIncident : "-"}
                    </TableCell>
                    <TableCell align="center">
                      <IconButton
                        color="primary"
                        onClick={() =>
                          navigate(`/incidents/${incident.id}/edit`)
                        }
                      >
                        <EditIcon />
                      </IconButton>
                      <IconButton
                        color="error"
                        onClick={() => handleDelete(incident.id)}
                      >
                        <DeleteIcon />
                      </IconButton>
                    </TableCell>
                  </TableRow>
                )
              )}
            </TableBody>
          </Table>
        </TableContainer>
      </Box>
    </>
  );
}
