import React from "react";
import {
  BrowserRouter as Router,
  Routes,
  Route,
  Navigate,
} from "react-router-dom";
import Sidebar from "./components/Sidebar";
import Dashboard from "./pages/Dashboard";
import IncidentForm from "./pages/IncidentForm";
import IncidentsList from "./pages/IncidentsList";
import IncidentEdit from "./pages/IncidentEdit";
import IncidentQualify from "./pages/IncidentQualify";
import SourcesAdmin from "./pages/SourcesAdmin";
import UsersAdmin from "./pages/UsersAdmin";
import EntitiesAdmin from "./pages/EntiteAdmin";
import LoginPage from "./pages/Login";

function App() {
  // Si tu veux forcer le login, remplace false par ta logique d’authentification
  const isLoggedIn = true; // à remplacer plus tard par un vrai test

  return (
    <Router>
      <div style={{ display: "flex" }}>
        <Sidebar />
        <main
          style={{
            flexGrow: 1,
            padding: "30px",
            minHeight: "100vh",
            background: "#f5f7fa",
          }}
        >
          <Routes>
            {/* Accueil dashboard */}
            <Route
              path="/"
              element={isLoggedIn ? <Dashboard /> : <Navigate to="/login" />}
            />
            <Route
              path="/dashboard"
              element={isLoggedIn ? <Dashboard /> : <Navigate to="/login" />}
            />

            {/* Saisie d'incident */}
            <Route
              path="/ajouter"
              element={isLoggedIn ? <IncidentForm /> : <Navigate to="/login" />}
            />

            {/* Liste des incidents */}
            <Route
              path="/liste"
              element={
                isLoggedIn ? <IncidentsList /> : <Navigate to="/login" />
              }
            />

            {/* Qualification et édition */}
            <Route
              path="/incident/:id/qualifier"
              element={
                isLoggedIn ? <IncidentQualify /> : <Navigate to="/login" />
              }
            />
            <Route
              path="/incident/:id"
              element={isLoggedIn ? <IncidentEdit /> : <Navigate to="/login" />}
            />

            {/* Admin (paramétrage) */}
            <Route
              path="/admin-sources"
              element={isLoggedIn ? <SourcesAdmin /> : <Navigate to="/login" />}
            />
            <Route
              path="/admin-utilisateurs"
              element={isLoggedIn ? <UsersAdmin /> : <Navigate to="/login" />}
            />
            <Route
              path="/admin-entites"
              element={
                isLoggedIn ? <EntitiesAdmin /> : <Navigate to="/login" />
              }
            />

            {/* Login */}
            <Route path="/login" element={<LoginPage />} />
            {/* Redirection par défaut */}
            <Route path="*" element={<Navigate to="/" />} />
          </Routes>
        </main>
      </div>
    </Router>
  );
}

export default App;
