import React, { useState, useEffect } from "react";
import {
  BrowserRouter as Router,
  Routes,
  Route,
  Navigate,
} from "react-router-dom";
import Sidebar from "./components/Sidebar";
import Dashboard from "./pages/Dashboard";
import IncidentForm from "./pages/IncidentForm";
import IncidentsList from "./pages/IncidentsList";
import IncidentEdit from "./pages/IncidentEdit";
import IncidentQualify from "./pages/IncidentQualify";
import SourcesAdmin from "./pages/SourcesAdmin";
import UsersAdmin from "./pages/UsersAdmin";
import EntitiesAdmin from "./pages/EntitiesAdmin";
import LoginPage from "./pages/LoginPage";

function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [loading, setLoading] = useState(true);

  // Vérifie la session auprès du backend
  useEffect(() => {
    const checkSession = async () => {
      const userId = localStorage.getItem("userId");
      if (!userId) {
        setIsLoggedIn(false);
        setLoading(false);
        return;
      }

      try {
        const res = await fetch("http://localhost:8080/api/users/me");
        if (res.ok) {
          setIsLoggedIn(true);
        } else {
          localStorage.clear();
          setIsLoggedIn(false);
        }
      } catch (err) {
        console.error("Erreur vérification session:", err);
        setIsLoggedIn(false);
      }
      setLoading(false);
    };

    checkSession();
  }, []);

  const handleLogin = (user) => {
    localStorage.setItem("userName", user.nom || user.email || "Utilisateur");
    localStorage.setItem("userId", user.id);
    localStorage.setItem("entite", user.entite?.libelle || "");
    setIsLoggedIn(true);
    window.location.href = "/";
  };

  const handleLogout = () => {
    localStorage.clear();
    setIsLoggedIn(false);
    window.location.href = "/login";
  };

  if (loading) return null; // ou un loader

  return (
    <Router>
      <div style={{ display: "flex" }}>
        {isLoggedIn && <Sidebar onLogout={handleLogout} />}
        <main
          style={{
            flexGrow: 1,
            padding: "30px",
            minHeight: "100vh",
            background: "None",
          }}
        >
          <Routes>
            <Route
              path="/login"
              element={<LoginPage onLogin={handleLogin} />}
            />
            <Route
              path="/"
              element={isLoggedIn ? <Dashboard /> : <Navigate to="/login" />}
            />
            <Route
              path="/dashboard"
              element={isLoggedIn ? <Dashboard /> : <Navigate to="/login" />}
            />
            <Route
              path="/ajouter"
              element={isLoggedIn ? <IncidentForm /> : <Navigate to="/login" />}
            />
            <Route
              path="/liste"
              element={
                isLoggedIn ? <IncidentsList /> : <Navigate to="/login" />
              }
            />
            <Route
              path="/incident/:id/qualifier"
              element={
                isLoggedIn ? <IncidentQualify /> : <Navigate to="/login" />
              }
            />
            <Route
              path="/incident/:id"
              element={isLoggedIn ? <IncidentEdit /> : <Navigate to="/login" />}
            />
            <Route
              path="/admin-sources"
              element={isLoggedIn ? <SourcesAdmin /> : <Navigate to="/login" />}
            />
            <Route
              path="/admin-utilisateurs"
              element={isLoggedIn ? <UsersAdmin /> : <Navigate to="/login" />}
            />
            <Route
              path="/admin-entites"
              element={
                isLoggedIn ? <EntitiesAdmin /> : <Navigate to="/login" />
              }
            />
            <Route path="*" element={<Navigate to="/" />} />
          </Routes>
        </main>
      </div>
    </Router>
  );
}

export default App;
